#include <stdio.h>
#include <stdlib.h>

/**2. La funci�n recibir� un array de 10 enteros y permitir� invertir el orden de sus elementos.
 Mostrar el array inicial y su inverso desde el main.*/

/**3. Desarrollar una funci�n que haga lo mismo que la funci�n stricmp pero sin utilizar la misma en ning�n caso.*/

int entero(int n);

int main()
{
    int nEntero = 0;
    int esEntero = 0;
    printf("----- Cosas -----\n\n");


    printf("Ingrese un numero entero: ");
    scanf("%d",&nEntero);

    esEntero = entero(nEntero);

    if(esEntero == 1){
        printf("El numero %d es un numero Entero.",nEntero);
    }else{
        printf("El numero %d no es un numero Entero.",nEntero);
    }

    return 0;
}

/**1. La funci�n recibir� un n�mero entero y determinar� si dicho n�mero es impar o no.
Retorna un entero que ser� evaluado desde el main.*/
int entero(int n){
    int todoOk = 0;
    int resto = 0;

    resto = n % 2;

    if(resto == 0){
        todoOk = 1;
    }

    return todoOk;
}
