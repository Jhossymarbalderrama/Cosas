#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 /**3. Crear dos funciones. Una que permita guardar en binario el array generado en el punto 1 y otra que permita leer
 dichos valores.
 Mostrar los valores desde el main.*/

 /**2. Realizar una funci�n que reciba un array de 3 flotantes y permita generar en memoria dinamica 2 flotantes mas.
 Desde el main cargar los espacios de memoria restantes y mostrar.*/


char array[3];
//int funcion2(x[], int tam);
void funcion1(void);
//int funcion3();

//int guardarBinario(vec[]);
//int mostrar(vec[]);


int main()
{
    float numero;

    printf("----- Promocion -----\n\n");
    funcion1();
    if( array == NULL)
    {
        printf("No se pudo asignar memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }


    for(int i = 0; i<3; i++){
        printf("Ingrese 3 numeros : ");
        scanf("%f",&numero);
        array[i] = numero;
    }

//    funcion2(array,2);


    return 0;
}


/**1. Realizar una funci�n que no reciba nada y que defina espacio en memoria din�mica para un array de 3 flotantes.
Desde el main cargar dicho array desde el �ltimo elemento hacia el primero y mostrar los valores.
Deber� utilizar notaci�n de punteros para resolver este punto.*/

void funcion1(void){
    malloc(sizeof(array)*3);
}


/**2. Realizar una funci�n que reciba un array de 3 flotantes y permita generar en memoria dinamica 2 flotantes mas.
 Desde el main cargar los espacios de memoria restantes y mostrar.*/
/*
void funcion2(x[], int tam){

    (x) realloc(x, sizeof(x) * tam);

}
*/


